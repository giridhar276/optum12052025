from huggingface_hub import InferenceClient
from PIL import Image
import io

# Hugging Face Token
HF_TOKEN = "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"

# Initialize client
client = InferenceClient(
    model="Salesforce/blip-image-captioning-base", 
    token=HF_TOKEN
)

# Load image and convert to bytes
img = Image.open("playing.jpg").convert("RGB")  # ensure RGB
buffer = io.BytesIO()
img.save(buffer, format="JPEG")
buffer.seek(0)

# Run image-to-text
caption = client.image_to_text(image=buffer)  # 🔹 use keyword argument
print("Generated Caption:", caption)
