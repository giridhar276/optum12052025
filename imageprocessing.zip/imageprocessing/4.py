from huggingface_hub import InferenceClient
from PIL import Image
import io
import os
from dotenv import load_dotenv

# 🔐 Load token from .env file
load_dotenv()
HF_TOKEN = os.getenv("HF_TOKEN")

# ⚙️ Initialize inference client
client = InferenceClient(
    model="Salesforce/blip-image-captioning-base",
    token=HF_TOKEN
)

# Load image and convert to bytes
img = Image.open("parrots.png").convert("RGB")
buffer = io.BytesIO()
img.save(buffer, format="JPEG")
buffer.seek(0)

# Generate caption
caption = client.image_to_text(image=buffer)
print("Generated Caption:", caption)
