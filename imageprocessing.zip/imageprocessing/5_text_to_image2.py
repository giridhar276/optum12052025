from huggingface_hub import InferenceClient
import os
from dotenv import load_dotenv

# Load token from .env
load_dotenv()  #pip install python-dotenv
HF_TOKEN = os.getenv("HF_TOKEN")

# Use a supported model
client = InferenceClient(
    model="black-forest-labs/FLUX.1-dev",  # Supported!
    token=HF_TOKEN
)

# Define your prompt
prompt = "a man dancing in the rain when it is cloudy"

# Generate image
image = client.text_to_image(prompt=prompt, guidance_scale=7.5, num_inference_steps=50)

# Save the image
image.save("dance.png")
print("Image saved as 'dragon_city1.png'")




''' Optional Parameters You Can Add
image = client.text_to_image(
    prompt="a fantasy castle floating in the clouds",
    negative_prompt="blurry, low resolution",
    guidance_scale=8.5,
    num_inference_steps=60,
    height=768,
    width=768
)
'''