from huggingface_hub import InferenceClient
from PIL import Image  # pip install pillow
import io
import os

HF_TOKEN = "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"

# ⚙️ Initialize inference client
client = InferenceClient( model="Salesforce/blip-image-captioning-base", token=HF_TOKEN )

# Load image and convert to bytes
img = Image.open("cars.jpg").convert("RGB")
buffer = io.BytesIO()
img.save(buffer, format="JPEG")
buffer.seek(0)

# Generate caption
caption = client.image_to_text(image=buffer)
print("Generated Caption:", caption)
